Browsers restrict local files.
It is recommended to use npm live-server.
https://www.npmjs.com/package/live-server

Install,
$npm install -g live-server

And issue the command in ethername directory,
$live-server
